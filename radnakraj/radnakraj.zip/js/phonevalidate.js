$(document).ready(function() {

    $('.phone_number').inputmask('(+999)99 9999-999');
});